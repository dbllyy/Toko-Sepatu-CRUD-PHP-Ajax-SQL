<?php include 'Header.php'; ?>

<?php
//Memanggil header_bayar untuk menjalankan fungsi yang diperlukan
require 'koneksi.php';
require 'fungsi.php';
//mendklarasikan variable yang berisi query
$rows = query('SELECT * FROM header_bayar');
?>


<!-- Page Content  -->
<div id="content" class="p-4 p-md-5">

    <nav class="navbar navbar-expand-lg navbar-light bg-active">
        <div class="container-fluid">

            <button type="button" id="sidebarCollapse" class="btn btn-dark">
                <i class="fa fa-bars"></i>
                <span class="sr-only">Toggle Menu</span>
            </button>
            <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>

        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent" style="color: white; ">
            <div class="nav navbar-nav ml-auto" class="nav-link" class="header-right">
                <form action="" method="post" class="form-inline  ">
                    <div class="input-group" class="input-group-append">
                        <input class="form-control mr-sm-2" type="text" name="keyword" placeholder="Search"
                            autocomplete="off" autofocus>
                        <button type="submit" name="cari" class="btn btn-success">
                            <span><i class="fa fa-search" aria-hidden="true"></i>Cari</button></span>
                    </div>
                </form>
            </div>
        </div>
    </nav>

    <!--Menampilkan judul untuk web ini-->
    <br>
    <h1 class="display-4">Halaman Header Bayar</h1>
    <hr>
    <h5 align="left"><a href="Tambah_Header.php"><button type="button" class="btn btn-success">
                <span><i class="fa fa-plus-circle"></i> Tambah Data</button></a></span></h5>
    <!--Membuat tabel untuk wadah data pada database-->
    <!-- <table class="table table-striped" > -->
    <table id="example" class="table table-striped table-bordered table-hover" style="width:100%">

        <!--Bagian head tabel-->
        <thead class="thead-dark">
            <tr align="center">
                <th scope="col">No Nota</th>
                <th scope="col">Tanggal</th>
                <th scope="col">ID Detail</th>
                <th scope="col">Total Pembelian</th>
                <th scope="col">Pembayaran</th>
                <th scope="col">Kembalian</th>
                <th scope="col">Action</th>
            </tr>
        </thead>

        <!--Memanggil isi dari data pada tabel header_bayar-->
        <!--Terdapat dua action yang memiliki fungsi untuk hapus dan ubah-->
        <?php
        $batas = 3;
        $halaman = @$_GET['halaman'];
        if (empty($halaman)) {
            $posisi = 0;
            $halaman = 1;
        } else {
            $posisi = ($halaman - 1) * $batas;
        }


        $data = mysqli_query($conn, "SELECT * FROM header_bayar LIMIT $posisi, $batas");
        $no = 1 + $posisi;

        //  untuk pencarian data
        if (isset($_POST['cari'])) {
            $keyword = $_POST['keyword'];
            $data = mysqli_query($conn, "SELECT * FROM header_bayar WHERE sisa_bayar LIKE '%$keyword%' OR no_nota
                                LIKE '%$keyword%' LIMIT $posisi, $batas");
        } else {
            $data = mysqli_query($conn, "SELECT * FROM header_bayar LIMIT $posisi, $batas");
        }
        while ($row = mysqli_fetch_array($data)) {
        ?>

        <tr>
            <td>
                <center><?php echo $row['no_nota']; ?></center>
            </td>
            <td>
                <center><?php echo $row['tanggal']; ?></center>
            </td>
            <td>
                <center><?php echo $row['id_detail']; ?></center>
            </td>
            <td>
                <center><?php echo $row['total_pembelian']; ?></center>
            </td>
            <td>
                <center><?php echo $row['bayar']; ?></center>
            </td>
            <td>
                <center><?php echo $row['sisa_bayar']; ?></center>
            </td>
            <td align="center">
                <a href="ubah_data_header.php?no_nota=<?php echo $row['no_nota']; ?>"><button type="button"
                        class="btn btn-primary">
                        <span><i class="fa fa-pencil-square-o"></i> Edit</button></span></a>
                <a href="hapus_header.php?no_nota=<?php echo $row['no_nota']; ?>"><button type="button" class="btn btn-danger">
                        <span><i class="fa fa-trash"></i> Hapus</button></span></a>
            </td>
        </tr>


        <?php
            $no++;
        }
        ?>

    </table>
    <?php
    $query2 = mysqli_query($conn, 'SELECT * FROM header_bayar');
    $jmldata = mysqli_num_rows($query2);
    $jmlhalaman = ceil($jmldata / $batas);
    
    ?>

    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <?php
            for ($i = 1; $i <= $jmlhalaman; $i++) {
                if ($i != $halaman) {
                    echo "<li class='page-item'><a class='page-link' href='Header_Bayar.php?halaman=$i'>$i</a></li>";
                } else {
                    echo "<li class='page-item'><a class='page-link'>$i</a></li>";
                }
            }
            
            ?>
        </ul>
    </nav>

    </body>

    </html>
</div>
</div>
<?php

mysqli_close($conn);
?>

<?php include 'Footer.php'; ?>
