<?php
//Memanggil hedaer_bayar untuk menjalankan fungsi yang diperlukan
require 'fungsi.php';

//Mengambil id dari url
$id = $_GET["no_nota"];

//Mengecek data berdasarkan id berhasil/tidak
if (hapus_header($id) > 0) {
	//Jika berhasil, maka akan tampil pesan ini
	echo "
				<script>
					alert('Data berhasil dihapus!');
					document.location.href = 'Header_Bayar.php';
				</script>
		";
} else {
	//Jika gagal, maka akan tampil pesan ini
	echo "
		<script>
					alert('Data gagal dihapus!');
					document.location.href = 'Header_Bayar.php';
				</script>
		";
}
