<?php include 'Header.php'; ?>

<style>
    .card-light-danger {
        background-color: #007bff;
    }

    .card-body {
        background-color: #f5f5f5;
        padding: 20px;
        border-radius: 5px;
        text-align: center;
    }

    .fs-30 {
        font-size: 30px;
        font-weight: bold;
        color: #007bff;
    }
</style>
<div id="content" class="p-4 p-md-5">
    <nav class="navbar navbar-expand-lg navbar-light bg-active">
        <div class="container-fluid">
            <button type="button" id="sidebarCollapse" class="btn btn-dark">
                <i class="fa fa-bars"></i>
                <span class="sr-only">Toggle Menu</span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent" style="color: white; ">
        </div>
    </nav>
    <?php

    //mendklarasikan variable yang berisi query
    $data = mysqli_query($conn, 'SELECT SUM(total_pembelian) as total FROM header_bayar');
    $header = mysqli_fetch_array($data);
    ?>
    <div class="col-md-6 stretch-card transparent">
        <div class="card card-light-danger">
            <div class="card-body">
                <p class="mb-4">Total Pemasukan</p>
                <p class="fs-30 mb-5" value="<?php echo $header['total']; ?>">Rp.
                    <?php echo number_format($header['total']); ?> </p>
                <p>Total Pembelian: <?php echo number_format($header['total']); ?></p>
            </div>
        </div>
    </div>
</div>
<?php
include_once 'footer.php';
?>
