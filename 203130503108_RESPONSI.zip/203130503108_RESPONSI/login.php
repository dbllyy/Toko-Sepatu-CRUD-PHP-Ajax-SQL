<?php

require('koneksi.php');

if (isset($_POST["login"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $check = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username' and password = '$password'");
    if (mysqli_num_rows($check) === 1) {
        echo "
        <script>
        alert('Login Berhasil');
        document.location.href = 'index.php';
        </script> ";
    } else {
        echo "
        <script>
        alert('Username/Password Salah');
        document.location.href = 'index.php';
        </script> ";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login!</title>
    <link rel="stylesheet" href="style2.css" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

</head>

<body class="main-bg">
    <div class="login-container text-c animated flipInX">
        <div>
            <h1 class="logo-badge text-whitesmoke"><span class="fa fa-user-circle"></span></h1>
        </div>
        <h3 class="text-whitesmoke">Selamat Datang Admin</h3>
        <p class="text-whitesmoke">Sign In</p>
        <div class="container-content">
            <form class="margin-t" action="login-proses.php" method="post">
                <div class="form-group">
                    <input type="text" class="form-control" name="username" placeholder="username" required="">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="password" placeholder="*****" required="">
                </div>
                <button type="submit" name="login" class="form-button button-l margin-b">Sign In</button>
                <!-- 
                <a class="text-darkyellow" href="#"><small>Forgot your password?</small></a>
                <p class="text-whitesmoke text-center"><small>Do not have an account?</small></p>
                <a class="text-darkyellow" href="#"><small>Sign Up</small></a> -->
            </form>
            <p class="margin-t text-whitesmoke"><small> Copyright &copy; Deby Li. 2020</small> </p>
        </div>
    </div>

</body>

</html>