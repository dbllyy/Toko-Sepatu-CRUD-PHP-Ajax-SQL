<?php

session_start();
include 'koneksi.php';
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));

if (empty($_SESSION['username']) and empty($_SESSION['password'])) {
    echo "<script> window.location = 'login.php'</script>";
}
?>


<?php

if (empty($_SESSION['username'])) {
    header('location:login.php?pesan=gagal');
}
include 'koneksi.php';
$sql = mysqli_query($conn, "SELECT * FROM user WHERE id_user='$_SESSION[id_user]'");
$data = mysqli_fetch_array($sql);

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Admin</title>
    <!-- <script src="https://kit.fontawesome.com/a076d05399.js"></script> -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">

    <!-- boss ripaldo -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap4.min.css">
    <style>
        #sidebar {
            background: #7800FF;
        }

        body {
            background-color: #FFFFFF;
        }
    </style>

</head>

<body>
    <div class="wrapper d-flex align-items-stretch">
        <nav id="sidebar">
            <div class="p-4 pt-5">
                <h4 style="color: white ">Toko Deby Li</h4>
                <ul class="list-unstyled components mb-5">
                    <li class="active">
                        <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <a href="#pagemenu" data-toggle="collapse" aria-expanded="false" class=""> Shell Shoes</a>
                        <ul class="collapse list-unstyled" id="pagemenu">
                            <li>
                                <a href="Merk.php">Merk</a>
                            </li>
                            <li>
                                <a href="Sepatu.php">Sepatu</a>
                            </li>
                            <li>
                                <a href="Detail_Bayar.php">Detail Bayar</a>
                            </li>
                            <li>
                                <a href="Header_Bayar.php">Header Bayar</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="viewharian.php">Pemasukan Harian</a>
                    </li>
                    <li>
                        <a href="Total_pemasukan.php">Total Pemasukan</a>
                    </li>
                    <li>
                        <a href="admin/index.html">Profile Admin</a>
                    </li>
                    <li>
                        <a href="logout.php" class="nav-link">Keluar</a>
                    </li>
                </ul>
        </nav>
