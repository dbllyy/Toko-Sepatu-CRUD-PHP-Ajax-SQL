<?php
//memanggil file fungsi untuk menjalankan program
require 'fungsi.php';

//mengambil id dari url
$id = $_GET["id_sepatu"];

//mendeklarasikan variable yang berisi query mysql "data sebelum di ubah"
$rows = query("SELECT * FROM sepatu WHERE id_sepatu = $id")[0];

//cek apakah input berhasil 
if (isset($_POST["submit"])) {
    if (ubah_sepatu($_POST) > 0) {
        //Jika berhasil, maka akan menampilkan pesan ini
        echo "
        <script>
            alert('Data berhasil diubah!');
            document.location.href = 'Sepatu.php';
        </script>";
    } else {
        //Jika tidak berhasil, maka akan menampilkan pesan ini
        echo "
		<script>
			alert('Data gagal diubah!');
			document.location.href = 'Sepatu.php';
		</script>";
    }
}
?>

<DOCTYPE html>
    <html>

    <head>
        <title>Ubah Data Sepatu</title>

        <!-- Membutuhkan meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    </head>

    <body>
        <!--Navbar pada bagian atas-->
        <nav class="navbar fix-top navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">Home</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <!--Bagian Menu Navbar-->
                        <a class="nav-link active" aria-current="page" href="Merk.php">Merk</a>
                        <a class="nav-link active" aria-current="page" href="Sepatu.php">Sepatu</a>
                        <a class="nav-link active" aria-current="page" href="Detail_Bayar.php">Detail Bayar</a>
                        <a class="nav-link active" aria-current="page" href="Header_Bayar.php">Header Bayar</a>
                    </div>
                </div>
            </div>
        </nav>

        <!--Menampilkan judul untuk web ini-->
        <br>
        <h1 class="display-4">Ubah Data Sepatu</h1>
        <hr>

        <!--Form untuk mengubah data pada tabel data merk-->
        <form class="form-horizontal" method="POST" action="">
            <!--Bagian untuk menampilkan id keluarga, tapi tidak terlihat-->
            <input type="hidden" name="id_sepatu" value="<?= $rows["id_sepatu"] ?>">

            <!--Bagian untuk menampilkan id keluarga, tapi tidak terlihat-->
            <input type="hidden" name="id_merk" value="<?= $rows["id_merk"] ?>">

            <!--Bagian input ubah "nama" pada tabel data merk-->
            <div class="row mb-3">
                <label for="ukuran" class="control-label col-sm-2">Ukuran</label>
                <div class="col-sm-10">
                    <input type="text" name="ukuran" class="form-control" id="ukuran" required value="<?= $rows["ukuran"] ?>">
                </div>
            </div>

            <!--Bagian input ubah "model_sepatu" pada tabel data merk-->
            <div class="row mb-3">
                <label for="warna" class="control-label col-sm-2">Warna</label>
                <div class="col-sm-10">
                    <input type="text" name="warna" class="form-control" id="warna" required value="<?= $rows["warna"] ?>">
                </div>
            </div>

            
            <!--Bagian input ubah "model_sepatu" pada tabel data merk-->
            <div class="row mb-3">
                <label for="harga" class="control-label col-sm-2">Harga Sepatu</label>
                <div class="col-sm-10">
                    <input type="text" name="harga" class="form-control" id="harga" required value="<?= $rows["harga"] ?>">
                </div>
            </div>

            
            <!--Bagian input ubah "model_sepatu" pada tabel data merk-->
            <div class="row mb-3">
                <label for="stok" class="control-label col-sm-2">Stok</label>
                <div class="col-sm-10">
                    <input type="text" name="stok" class="form-control" id="stok" required value="<?= $rows["stok"] ?>">
                </div>
            </div>

            <!--Bagian input ubah "submit" pada tabel data merk-->
            <hr>
            <button class="btn btn-success type="submit" name="submit">Ubah Data</button>
            <a class="btn btn-warning" href="Sepatu.php">Kembali</a>
            <hr>
        </form>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    </body>

    </html>