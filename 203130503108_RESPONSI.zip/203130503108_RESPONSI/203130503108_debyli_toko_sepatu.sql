-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2022 at 09:38 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugas 2`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `banyak_Transaksi` ()  BEGIN
	SELECT COUNT(no_nota) AS 'banyak transaksi' FROM header_bayar; 
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DelateData_detail` (IN `hps_detail` INT(4))  BEGIN
	DELETE FROM detail_bayar WHERE id_detail=hps_detail;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DelateData_header` (IN `hps_nota` INT(3))  BEGIN
	DELETE FROM header_bayar WHERE no_nota=hps_nota;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DelateData_merk` (IN `hps_merk` INT(4))  BEGIN
	DELETE FROM merk WHERE id_merk=hps_merk;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DelateData_Sepatu` (IN `hps_sepatu` INT(4))  BEGIN
	DELETE FROM sepatu WHERE id_sepatu=hps_sepatu;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `harga_sepatu_termahal` ()  BEGIN
	SELECT  id_sepatu, harga FROM sepatu
	WHERE harga = ( SELECT MAX(harga) FROM sepatu);
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `harga_sepatu_termurah` ()  BEGIN
	SELECT  id_sepatu, harga FROM sepatu
	WHERE harga = ( SELECT MIN(harga) FROM sepatu);
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `HitungTotalPembelian` ()  BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING, NOT FOUND ROLLBACK;
	START TRANSACTION;
	SELECT SUM(total_pembelian) AS 'Banyak Pembelian' FROM header_bayar;
	COMMIT;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `HitungTotal_Pembelian` ()  BEGIN
	SELECT SUM(total_pembelian) AS 'Banyak Pembelian' FROM header_bayar;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertData_detail` (IN `id_detail` INT(4), IN `id_sepatu` INT(8), IN `jumlah_beli` INT(8))  BEGIN
	INSERT INTO detail_bayar (id_detail, id_sepatu, jumlah_beli) VALUES (id_detail, id_sepatu, jumlah_beli); 
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertData_header` (IN `no_nota` INT(5), IN `tanggal` DATE, IN `id_detail` INT(5), IN `total_pembelian` VARCHAR(35), IN `bayar` VARCHAR(35), IN `sisa_bayar` VARCHAR(35))  BEGIN
	INSERT INTO header_bayar (no_nota, tanggal, id_detail, total_pembelian, bayar, sisa_bayar) 
	VALUES (no_nota, tanggal, id_detail, total_pembelian, bayar, sisa_bayar);
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertData_merk` (IN `id_merk` INT(4), IN `nama_merk` VARCHAR(20), IN `model_sepatu` VARCHAR(20))  BEGIN
	INSERT INTO merk (id_merk, nama_merk, model_sepatu) VALUES (id_merk, nama_merk, model_sepatu); 
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertData_Sepatu` (IN `id_sepatu` INT(4), IN `id_merk` INT(4), IN `ukuran` INT(2), IN `warna` VARCHAR(10), IN `harga` VARCHAR(35), IN `stok` INT(10))  BEGIN
	INSERT INTO sepatu (id_sepatu, id_merk, ukuran, warna, harga, stok) VALUES (id_sepatu, id_merk, ukuran, warna, harga, stok); 
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `merk_sepatu` ()  BEGIN
	SELECT model_sepatu, MAX(jumlah_beli) FROM merk
	JOIN sepatu USING(id_merk)
	JOIN detail_bayar USING(id_sepatu);
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateData_detail` (IN `id_updetail` INT(4), IN `upjumlah_beli` INT(5))  BEGIN
	UPDATE detail_bayar SET jumlah_beli = upjumlah_beli WHERE id_detail = id_updetail;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateData_header` (IN `no_nota_up` INT(3), IN `tanggalnya` DATE, IN `total_pembeliannya` VARCHAR(11), IN `up_bayar` VARCHAR(35), IN `upsisabayar` VARCHAR(35))  BEGIN
	UPDATE header_bayar SET tanggal = tanggalnya,total_pembelian = total_pembeliannya, bayar = up_bayar, sisa_bayar = upsisabayar
	WHERE no_nota = no_nota_up;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateData_merk` (IN `upid_merk` INT(4), IN `up_merk` VARCHAR(20), IN `up_model` VARCHAR(20))  BEGIN
	UPDATE merk SET nama_merk = up_merk, model_sepatu = up_model WHERE id_merk = upid_merk;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateData_Sepatu` (IN `up_idsepatu` INT(4), IN `up_ukuran` INT(2), IN `up_warna` VARCHAR(10), IN `up_harga` VARCHAR(35), IN `upstok` INT(10))  BEGIN
	UPDATE sepatu SET ukuran = up_ukuran, warna=up_warna, harga=up_harga,stok=upstok
	WHERE id_sepatu = up_idsepatu;
	END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `BuatNoNota` (`no_notaterbuat` INT(10)) RETURNS VARCHAR(15) CHARSET utf8mb4 BEGIN
	DECLARE faktur VARCHAR(10);
	SELECT CONCAT_WS("-", DATE_FORMAT(tanggal, '%y%m%d'), LPAD(no_nota, 2, "0")) 
		FROM header_bayar WHERE no_nota = no_notaterbuat INTO faktur;
	RETURN faktur;
    END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `TotalPemasukan_Harian` (`tanggalnya` DATE) RETURNS INT(50) BEGIN
DECLARE total INT(50);
    SELECT SUM(header_bayar.total_pembelian) INTO total FROM header_bayar WHERE tanggal = tanggalnya;
    RETURN total;
    END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `coba`
-- (See below for the actual view)
--
CREATE TABLE `coba` (
`nama_merk` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `detail_bayar`
--

CREATE TABLE `detail_bayar` (
  `id_detail` int(4) NOT NULL,
  `id_sepatu` int(8) DEFAULT NULL,
  `jumlah_beli` int(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `detail_bayar`
--

INSERT INTO `detail_bayar` (`id_detail`, `id_sepatu`, `jumlah_beli`) VALUES
(772, 222, 2),
(773, 223, 4),
(774, 224, 2),
(775, 225, 5),
(776, 223, 5);

--
-- Triggers `detail_bayar`
--
DELIMITER $$
CREATE TRIGGER `EditStok` AFTER INSERT ON `detail_bayar` FOR EACH ROW BEGIN
	UPDATE sepatu SET stok = stok-NEW.jumlah_beli
	WHERE id_sepatu=NEW.id_sepatu;

    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `header_bayar`
--

CREATE TABLE `header_bayar` (
  `no_nota` int(5) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `id_detail` int(5) DEFAULT NULL,
  `total_pembelian` varchar(35) DEFAULT NULL,
  `bayar` varchar(35) DEFAULT NULL,
  `sisa_bayar` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `header_bayar`
--

INSERT INTO `header_bayar` (`no_nota`, `tanggal`, `id_detail`, `total_pembelian`, `bayar`, `sisa_bayar`) VALUES
(92, '2022-02-14', 772, '5600000', '6000000', '50000'),
(93, '2022-01-22', 773, '2400000', '2500000', '100000'),
(94, '2022-03-19', 774, '1000000', '1000000', '2'),
(95, '2022-03-19', 775, '2150000', '2200000', '50000'),
(97, '2022-04-02', 776, '200000', '105000', '95000');

--
-- Triggers `header_bayar`
--
DELIMITER $$
CREATE TRIGGER `HapusDetailBayar` AFTER DELETE ON `header_bayar` FOR EACH ROW BEGIN
	DELETE detail_bayar FROM detail_bayar WHERE id_detail = old.id_detail;

    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `merk`
--

CREATE TABLE `merk` (
  `id_merk` int(4) NOT NULL,
  `nama_merk` varchar(20) DEFAULT NULL,
  `model_sepatu` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `merk`
--

INSERT INTO `merk` (`id_merk`, `nama_merk`, `model_sepatu`) VALUES
(111, 'Vanz', 'Running'),
(112, 'Ventela', 'Sneakers'),
(113, 'Nike', 'Sneakers'),
(114, 'Puma', 'Sneakers'),
(115, 'Nike Naw', 'boots'),
(116, 'Piero', 'Sneakers');

-- --------------------------------------------------------

--
-- Stand-in structure for view `pemasukan_harian`
-- (See below for the actual view)
--
CREATE TABLE `pemasukan_harian` (
`no_nota` int(5)
,`tanggal` date
,`sum(total_pembelian)` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `semua`
-- (See below for the actual view)
--
CREATE TABLE `semua` (
`no_nota` int(5)
,`nama_merk` varchar(20)
,`model_sepatu` varchar(20)
,`ukuran` int(2)
,`warna` varchar(10)
,`harga` varchar(35)
,`stok` int(10)
,`jumlah_beli` int(8)
,`tanggal` date
,`total_pembelian` varchar(35)
,`bayar` varchar(35)
,`sisa_bayar` varchar(35)
);

-- --------------------------------------------------------

--
-- Table structure for table `sepatu`
--

CREATE TABLE `sepatu` (
  `id_sepatu` int(4) NOT NULL,
  `id_merk` int(4) DEFAULT NULL,
  `ukuran` int(2) DEFAULT NULL,
  `warna` varchar(10) DEFAULT NULL,
  `harga` varchar(35) DEFAULT NULL,
  `stok` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sepatu`
--

INSERT INTO `sepatu` (`id_sepatu`, `id_merk`, `ukuran`, `warna`, `harga`, `stok`) VALUES
(221, 111, 45, 'YELLOW', '340000', 9),
(222, 112, 41, 'RED', '280000', 15),
(223, 113, 43, 'GREY MUDA', '600000', 20),
(224, 114, 34, 'blue', '300000', 10),
(225, 115, 39, 'red', '430000', 10),
(226, 116, 10, 'YELLOW lig', '150000', 10);

--
-- Triggers `sepatu`
--
DELIMITER $$
CREATE TRIGGER `HapusDataSepatu` AFTER DELETE ON `sepatu` FOR EACH ROW BEGIN
    DELETE FROM merk WHERE id_merk = OLD.id_merk;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(35) NOT NULL,
  `username` varchar(35) NOT NULL,
  `Password` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `username`, `Password`) VALUES
(1, 'Richo Albert Tio', '203030503099', '203030503099');

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_sepatu`
-- (See below for the actual view)
--
CREATE TABLE `view_sepatu` (
`nama_merk` varchar(20)
,`model_sepatu` varchar(20)
,`ukuran` int(2)
,`warna` varchar(10)
,`harga` varchar(35)
);

-- --------------------------------------------------------

--
-- Structure for view `coba`
--
DROP TABLE IF EXISTS `coba`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `coba`  AS   (select `merk`.`nama_merk` AS `nama_merk` from `merk` group by `merk`.`nama_merk`)  ;

-- --------------------------------------------------------

--
-- Structure for view `pemasukan_harian`
--
DROP TABLE IF EXISTS `pemasukan_harian`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pemasukan_harian`  AS   (select `header_bayar`.`no_nota` AS `no_nota`,`header_bayar`.`tanggal` AS `tanggal`,sum(`header_bayar`.`total_pembelian`) AS `sum(total_pembelian)` from `header_bayar` group by `header_bayar`.`tanggal`)  ;

-- --------------------------------------------------------

--
-- Structure for view `semua`
--
DROP TABLE IF EXISTS `semua`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `semua`  AS   (select `header_bayar`.`no_nota` AS `no_nota`,`merk`.`nama_merk` AS `nama_merk`,`merk`.`model_sepatu` AS `model_sepatu`,`sepatu`.`ukuran` AS `ukuran`,`sepatu`.`warna` AS `warna`,`sepatu`.`harga` AS `harga`,`sepatu`.`stok` AS `stok`,`detail_bayar`.`jumlah_beli` AS `jumlah_beli`,`header_bayar`.`tanggal` AS `tanggal`,`header_bayar`.`total_pembelian` AS `total_pembelian`,`header_bayar`.`bayar` AS `bayar`,`header_bayar`.`sisa_bayar` AS `sisa_bayar` from (((`merk` join `sepatu` on(`merk`.`id_merk` = `sepatu`.`id_merk`)) join `detail_bayar` on(`sepatu`.`id_sepatu` = `detail_bayar`.`id_sepatu`)) join `header_bayar` on(`detail_bayar`.`id_detail` = `header_bayar`.`id_detail`)))  ;

-- --------------------------------------------------------

--
-- Structure for view `view_sepatu`
--
DROP TABLE IF EXISTS `view_sepatu`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_sepatu`  AS   (select `m`.`nama_merk` AS `nama_merk`,`m`.`model_sepatu` AS `model_sepatu`,`s`.`ukuran` AS `ukuran`,`s`.`warna` AS `warna`,`s`.`harga` AS `harga` from (`merk` `m` join `sepatu` `s` on(`m`.`id_merk` = `s`.`id_merk`)) where `m`.`nama_merk` = 'Puma')  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_bayar`
--
ALTER TABLE `detail_bayar`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `id_sepatu` (`id_sepatu`);

--
-- Indexes for table `header_bayar`
--
ALTER TABLE `header_bayar`
  ADD PRIMARY KEY (`no_nota`),
  ADD KEY `id_detail` (`id_detail`);

--
-- Indexes for table `merk`
--
ALTER TABLE `merk`
  ADD PRIMARY KEY (`id_merk`);

--
-- Indexes for table `sepatu`
--
ALTER TABLE `sepatu`
  ADD PRIMARY KEY (`id_sepatu`),
  ADD KEY `id_merk` (`id_merk`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_bayar`
--
ALTER TABLE `detail_bayar`
  ADD CONSTRAINT `detail_bayar_ibfk_1` FOREIGN KEY (`id_sepatu`) REFERENCES `sepatu` (`id_sepatu`);

--
-- Constraints for table `header_bayar`
--
ALTER TABLE `header_bayar`
  ADD CONSTRAINT `header_bayar_ibfk_1` FOREIGN KEY (`id_detail`) REFERENCES `detail_bayar` (`id_detail`);

--
-- Constraints for table `sepatu`
--
ALTER TABLE `sepatu`
  ADD CONSTRAINT `sepatu_ibfk_1` FOREIGN KEY (`id_merk`) REFERENCES `merk` (`id_merk`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
