<?php
//file ini merupakan file login untuk user
session_start();
include "koneksi.php";

//mendapatkan input dari pengguna
$username=$_POST['username'];
$password=$_POST['password'];

//mencek di database tabel user adakah username dan password
$login="SELECT * FROM user WHERE username='$username'";
$cek=mysqli_query($conn,$login);
$ketemu=mysqli_num_rows($cek);

$login2="SELECT * FROM user WHERE password='$password'";
$cek2=mysqli_query($conn,$login2);
$ketemu2=mysqli_num_rows($cek2);

$login3="SELECT * FROM user WHERE username='$username' AND password='$password'";
$cek3=mysqli_query($conn,$login3);
$ketemu3=mysqli_num_rows($cek3);

$r=mysqli_fetch_array($cek3);

//menampilkan pesan gagal jika belum memasukkan username dan password
if ($ketemu ==0 & $ketemu2==0){
    echo "<script> alert ('Username dan Password anda tidak valid ! Mohon periksa kembali.');
    window.location = 'login.php'</script>";
}
//menampilkan pesan gagal jika username salah
else if ($ketemu ==0){
    echo "<script> alert ('Username dan Password anda tidak valid ! Mohon periksa kembali.');
    window.location = 'login.php'</script>";
}
//menampilkan pesan gagal jika password salah
else if ($ketemu2 ==0){
    echo "<script> alert ('Username dan Password anda tidak valid ! Mohon periksa kembali.');
    window.location = 'login.php'</script>";
}

//jika ketemu dibuat sesi loginnya
else {
    //detail sesi loginnya
    $_SESSION['id_user']=$r['id_user'];
    $_SESSION['nama_user']=$r['nama_user'];
    $_SESSION['username']=$r['username'];
    $_SESSION['password']=$r['password'];


//login berhasil
echo "<script> alert ('Login Berhasil');
    window.location = 'index.php'</script>";
}
