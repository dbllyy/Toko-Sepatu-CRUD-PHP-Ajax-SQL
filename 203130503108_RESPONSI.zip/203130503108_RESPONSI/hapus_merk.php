<?php
//Memanggil merk untuk menjalankan fungsi yang diperlukan
require 'fungsi.php';

//Mengambil id dari url
$id = $_GET["id_merk"];

//Mengecek data berdasarkan id berhasil/tidak
if (hapus_merk($id) > 0) {
	//Jika berhasil, maka akan tampil pesan ini
	echo "
				<script>
					alert('Data berhasil dihapus!');
					document.location.href = 'Merk.php';
				</script>
		";
} else {
	//Jika gagal, maka akan tampil pesan ini
	echo "
		<script>
					alert('Data gagal dihapus!');
					document.location.href = 'Merk.php';
				</script>
		";
}
