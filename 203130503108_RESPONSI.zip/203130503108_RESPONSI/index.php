<?php include "Header.php"; ?>

<!-- Page Content  -->
<div id="content" class="p-4 p-md-5">

    <nav class="navbar navbar-expand-lg navbar-light bg-dark">
        <div class="container-fluid">

            <button type="button" id="sidebarCollapse" class="btn btn-secondary">
                <i class="fa fa-bars"></i>
                <span class="sr-only">Toggle Menu</span>
            </button>
            <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
                
            <div class="collapse navbar-collapse" id="navbarSupportedContent" style="color: white; ">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" class="header-right" href="#about" style="color: white;">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" class="header-right" href="#product" style="color: white;">Shell Shoes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" class="header-right" href="#testimoni" style="color: white;">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <html lang="en">

    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" />
        <link rel="stylesheet" href="styles1.css" />
        <link rel="stylesheet" href="responsive.css" />
        <title>Sport Station</title>
    </head>
    <h2 class="mb-4">Shoes Shop</h2>

    <body>
        <table>
            <tr>
                <td>
                    
                </td>
            </tr>
        </table>
        <!-- bagian sidebar -->
        <input type="checkbox" id="check" />
        <div class="sidebar">
            <ul>
                <li><a href="#about">about</a></li>
                <li><a href="#product">products</a></li>
                <li><a href="#testimoni">testimonial</a></li>
                <li><a href="#contact">contact</a></li>
            </ul>
        </div>


        <!-- bagian banner -->
        <section class="banner">
            <div class="container">
                <div class="banner-left">
                    <h2>
                        Hai...<br />
                        Butuh Sneackers <span class="efek-ngetik"></span>
                    </h2>
                    <p>Di Sport Station Aja</p>
                </div>
            </div>
        </section>

        <!-- bagian about -->
        <section id="about">
            <div class="container">
                <h3>About</h3>
                <p>
                    Sepatu dari toko kami dirancang untuk mempermudah segala aktivitas pada setiap kegiatan yang dilakukan terutama di luar ruangan. Tidak hanya itu, kami menginspirasi semua kalangan untuk mengubah setiap mimpi mereka hanya dengan
                    melangkah dan berjalan dengan sepatu kets ini.
                </p>
                <p>
                    Hampir semua orang mendedikasikan sepatu ini hanya untuk setiap kebutuhan dan keinginan. Terutama ada pada keunggulan produk sepatu kami yang di buat dengan nyaman dan mudah digunakan. Kami juga membuat pelanggan tidak lupa akan
                    ciri khas pada setiap produk andalan dalam jenjang sepatu terbaik dari setiap perkembangan zaman.
                </p>
            </div>
        </section>

        <!-- bagian product -->
        <section id="product">
            <div class="container">
                <h3>Products</h3>
                <div class="col-4">
                    <a href="">
                        <img src="img/img01c.jpg" />
                        <h2>Rp.399.000</h2>
                        <span>Nike 01</span>
                    </a>
                </div>

                <div class="col-4">
                    <a href="">
                        <img src="img/img02.jpg" />
                        <h2>Rp.459.000</h2>
                        <span>Adidas 02</span>
                    </a>
                </div>

                <div class="col-4">
                    <a href="">
                        <img src="img/img03.jpg" />
                        <h2>Rp.259.000</h2>
                        <span>Vans 3</span>
                    </a>
                </div>

                <div class="col-4">
                    <a href="">
                        <img src="img/img04.jpg" />
                        <h2>Rp.329.000</h2>
                        <span>Reebook 4</span>
                    </a>
                </div>

                <div class="col-4">
                    <a href="">
                        <img src="img/img05.jpg" />
                        <h2>Rp.759.000</h2>
                        <span>Adidas 23</span>
                    </a>
                </div>

                <div class="col-4">
                    <a href="">
                        <img src="img/img06.jpg" />
                        <h2>Rp.229.000</h2>
                        <span>Nike 6</span>
                    </a>
                </div>

                <div class="col-4">
                    <a href="">
                        <img src="img/skechers.jpg" />
                        <h2>Rp.899.000</h2>
                        <span>Skechers</span>
                    </a>
                </div>

                <div class="col-4">
                    <a href="">
                        <img src="img/asics.jpg" />
                        <h2>Rp.1.259.300</h2>
                        <span>ASICS GEL-LYTE III</span>
                    </a>
                </div>
            </div>
        </section>

        <!-- bagian testimonial -->
        <section id="testimoni">
            <div class="container">
                <h3>Testimonial</h3>
                <p></p>
                <span class="heading">User Rating</span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star"></span>
                <p class="space">4.1 average based on 254 reviews.</p>
                <hr style="border: 3px solid #f1f1f1" />

                <div class="row">
                    <div class="side">
                        <div>5 star</div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-5"></div>
                        </div>
                    </div>
                    <div class="side right">
                        <div>150</div>
                    </div>
                    <div class="side">
                        <div>4 star</div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-4"></div>
                        </div>
                    </div>
                    <div class="side right">
                        <div>63</div>
                    </div>
                    <div class="side">
                        <div>3 star</div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-3"></div>
                        </div>
                    </div>
                    <div class="side right">
                        <div>15</div>
                    </div>
                    <div class="side">
                        <div>2 star</div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-2"></div>
                        </div>
                    </div>
                    <div class="side right">
                        <div>6</div>
                    </div>
                    <div class="side">
                        <div>1 star</div>
                    </div>
                    <div class="middle">
                        <div class="bar-container">
                            <div class="bar-1"></div>
                        </div>
                    </div>
                    <div class="side right">
                        <div>20</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- bagian contact -->
        <section id="contact">
            <div class="container">
                <h3>Contact</h3>
                <div class="col-3">
                    <h4>Address</h4>
                    <p>Jl. Piranha XXI A , Indonesia</p>
                </div>

                <div class="col-3">
                    <h4>Email</h4>
                    <p>debyli@mhs.eng.upr.ac.id</p>
                </div>

                <div class="col-3">
                    <h4>Telephone</h4>
                    <p>087877602333</p>
                </div>

                <div class="col-3">
                    <h4>Instagram</h4>
                    <p>dbllyy</p>
                </div>
            </div>
        </section>

        <!-- bagian footer -->
        <footer>
            <div class="container">
                <small>Copyright &copy; 2023 - </small>
            </div>
        </footer>
        <script src="js2/script.js"></script>
    </body>

    </html>

</div>
</div>
<?php include "Footer.php"; ?>