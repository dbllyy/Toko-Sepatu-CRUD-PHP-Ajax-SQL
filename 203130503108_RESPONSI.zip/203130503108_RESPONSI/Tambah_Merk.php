<?php
//Memanggil fungsi agar dapat menjalankan program tertentu
require 'fungsi.php';

//Mengecek apakah data berhasil di tambah
if (isset($_POST["submit"])) {
    if (tambah_merk($_POST) > 0) {
        //Jika berhasil, maka akan muncul pesan ini
        echo "
        <script>
            alert('Data berhasil ditambahkan!');
            document.location.href = 'Merk.php';
        </script>";
    } else {
        //Jika tidak berhasil, maka akan muncul pesan ini
        echo "
		<script>
			alert('Data gagal ditambahkan!');
			document.location.href = 'Merk.php';
		</script>";
    }
}
?>

<?php
include("koneksi.php");
$data = mysqli_query($conn, "SELECT max((id_merk) + 1) as id_me FROM merk");
$row = mysqli_fetch_array($data);
?>

<DOCTYPE html>
    <html>
    <head>
        <title>Tambah Data Merk</title>

        <!-- Membutuhkan meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    </head>

    <body>
        <!--Navbar pada bagian atas-->
        <nav class="navbar fix-top navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">Home</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <!--Bagian Menu Navbar-->
                        <a class="nav-link active" aria-current="page" href="Merk.php">Merk</a>
                        <a class="nav-link active" aria-current="page" href="Sepatu.php">Sepatu</a>
                        <a class="nav-link active" aria-current="page" href="Detail_Bayar.php">Detail Bayar</a>
                        <a class="nav-link active" aria-current="page" href="Header_Bayar.php">Header Bayar</a>
                    </div>
                </div>
            </div>
        </nav>
        <!--Navbar pada bagian atas-->
        
        <nav class="navbar fix-top navbar-expand-lg navbar-dark bg-">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">Home</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <!--Bagian Menu Navbar-->
                        <a class="nav-link active" aria-current="page" href="Merk.php">Merk</a>
                        <a class="nav-link active" aria-current="page" href="Sepatu.php">Sepatu</a>
                        <a class="nav-link active" aria-current="page" href="Detail_Bayar.php">Detail Bayar</a>
                        <a class="nav-link active" aria-current="page" href="Header_Bayar.php">Header Bayar</a>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container">
             <!--Menampilkan judul untuk web ini-->
        <br>
        <h1 class="display-4">Tambah Data Merk</h1>
        <hr>

        <!--Form untuk input data yang akan di tambah-->
        <form class="form-horizontal" method="POST" action="">
            <!--Bagian untuk input id merk-->
            <div class="mb-3 row">
                <label for="id_merk" class="col-sm-2 col-form-label">ID Merk</label>
                <div class="col-sm-10">
                    <input type="text" name="id_merk" class="form-control" id="id_merk" value=" <?php echo $row['id_me']; ?>">

                </div>
            </div>

            <!--Bagian untuk input nama merk-->
            <div class="mb-3 row">
                <label for="nama_merk" class="col-sm-2 col-form-label">Nama Merk</label>
                <div class="col-sm-10">
                    <input type="text" name="nama_merk" class="form-control" id="nama_merk">
                </div>
            </div>

            <!--Bagian untuk input Model Sepatu-->
            <div class="mb-3 row">
                <label for="model_sepatu" class="col-sm-2 col-form-label">Model Sepatu</label>
                <div class="col-sm-10">
                    <input type="text" name="model_sepatu" class="form-control" id="model_sepatu">
                </div>
            </div>

            <!--Bagian button untuk submit dan kembali-->
            <hr>
            <button class="btn btn-success" type="submit" name="submit">Tambah Data</button>
            <a href="Merk.php" onclick=" return confirm ('Apakah anda ingin membatalkan data ini?');"><button
          type="button" class="btn btn-danger">
          <span><i class="fa fa-arrow-left white"></i> Batal</button></span></a>
            <!-- <i class="fa-solid fa-delete-left"></i> -->
            <hr>
        </form>

</div>
       
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    </body>

    </html>