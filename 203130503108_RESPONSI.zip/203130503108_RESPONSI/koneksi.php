<!-- Bagian untuk membuat conn antara php dengan mysql -->
<?php
//Deklarasi variabel untuk conn
$host="localhost"; //Nama localhost tempat menyimpan database
$user="root"; //Nama pengguna
$pass=""; //Password
$database="203130503108_debyli_toko_sepatu"; //Nama database

//Memasukan variabel yang berisi argumen  ke dalam syntax mysqli
$conn= new mysqli($host, $user, $pass, $database);
//cek kondisi 
if ($conn->connect_error){ 
    die("Connection failed: " . $conn->connect_error); //Jika conn error maka conn database gagal
}
// echo "Connected successfully"; //Jika kondisi tidak error maka conn berhasil
// Ketika berhasil maka akan menjalankan database yang dimasukan ke dalam variabel
$hasil=mysqli_select_db($conn,$database); 
?>