<?php
//Memanggil fungsi agar dapat menjalankan program tertentu
require 'fungsi.php';

//Mengecek apakah data berhasil di tambah
if (isset($_POST['submit'])) {
    if (tambah_header($_POST) > 0) {
        //Jika berhasil, maka akan muncul pesan ini
        echo "
        <script>
            alert('Data berhasil ditambahkan!');
            document.location.href = 'Header_Bayar.php';
        </script>";
    } else {
        //Jika tidak berhasil, maka akan muncul pesan ini
        echo "
		<script>
			alert('Data gagal ditambahkan!');
			document.location.href = 'Header_Bayar.php';
		</script>";
    }
}
?>

<?php
include 'koneksi.php';
$data = mysqli_query($conn, 'SELECT max((no_nota) + 1) as id_he FROM header_bayar');
$row = mysqli_fetch_array($data);
?>

<?php
include 'koneksi.php';
$data1 = mysqli_query($conn, 'SELECT max(id_detail) as id_de FROM detail_bayar');
$row1 = mysqli_fetch_array($data1);
?>


<DOCTYPE html>
    <html>

    <head>
        <title>Tambah Data Header Bayar</title>

        <!-- Membutuhkan meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    </head>

    <body>
        <!--Navbar pada bagian atas-->
        <nav class="navbar fix-top navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">Home</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <!--Bagian Menu Navbar-->
                        <a class="nav-link active" aria-current="page" href="Merk.php">Merk</a>
                        <a class="nav-link active" aria-current="page" href="Sepatu.php">Sepatu</a>
                        <a class="nav-link active" aria-current="page" href="Detail_Bayar.php">Detail Bayar</a>
                        <a class="nav-link active" aria-current="page" href="Header_Bayar.php">Header Bayar</a>
                    </div>
                </div>
            </div>
        </nav>

        <!--Menampilkan judul untuk web ini-->
        <div class="container">
            <br>
            <h1 class="display-4">Tambah Data Header</h1>
            <hr>

            <!--Form untuk input data yang akan di tambah-->
            <form class="form-horizontal" method="POST" name="autoSumForm" action="">
                <!--Bagian untuk input id merk-->
                <div class="mb-3 row">
                    <label for="no_nota" class="col-sm-2 col-form-label">No Nota</label>
                    <div class="col-sm-10">
                        <input type="text" name="no_nota" class="form-control" id="no_nota"
                            value=" <?php echo $row['id_he']; ?>">
                    </div>
                </div>

                <!--Bagian untuk input nama merk-->
                <div class="mb-3 row">
                    <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
                    <div class="col-sm-10">
                        <input type="date" name="tanggal" class="form-control" id="tanggal">
                    </div>
                </div>

                <!--Bagian untuk input Model Sepatu-->
                <div class="mb-3 row">
                    <label for="id_detail" class="col-sm-2 col-form-label">ID Detail</label>
                    <div class="col-sm-10">
                        <input type="text" name="id_detail" class="form-control" id="id_detail"
                            onFocus="startCalc();" onBlur="stopCalc();">
                    </div>
                </div>

                <!--Bagian untuk input Model Sepatu-->

                <div class="mb-3 row">
                    <label for="total_pembelian" class="col-sm-2 col-form-label">Total Harga</label>
                    <div class="col-sm-10">
                        <input type="text" name="total_pembelian" onFocus="startCalc();" onBlur="stopCalc();"
                            class="form-control" id="total_pembelian">
                    </div>
                </div>

                <!--Bagian diskon-->
                <div class="mb-3 row">
                    <label for="diskon" class="col-sm-2 col-form-label">Diskon</label>
                    <div class="col-sm-10">
                        <input type="number" name="diskon" onFocus="startCalc();" onBlur="stopCalc();"
                            class="form-control" id="diskon">
                    </div>
                </div>

                <!--Bagian untuk input Model Sepatu-->
                <div class="mb-3 row">
                    <label for="bayar" class="col-sm-2 col-form-label">Bayar</label>
                    <div class="col-sm-10">
                        <input type="text" name="bayar" class="form-control" id="bayar" onFocus="startCalc();"
                            onBlur="stopCalc();">
                    </div>
                </div>

                <!--Bagian untuk input Model Sepatu-->
                <div class="mb-3 row">
                    <label for="sisa_bayar" class="col-sm-2 col-form-label"> Total Bayar</label>
                    <div class="col-sm-10">
                        <input type="text" name="sisa_bayar" class="form-control" id="sisa_bayar">
                    </div>
                </div>

                <!--Bagian button untuk submit dan kembali-->
                <hr>
                <button class="btn btn-success" type="submit" name="submit">Tambah Data</button>
                <a href="Merk.php" onclick=" return confirm ('Apakah anda ingin membatalkan data ini?');"><button
                        type="button" class="btn btn-danger">
                        <span><i class="fa fa-arrow-left white"></i> Batal</button></span></a>
                <!-- <i class="fa-solid fa-delete-left"></i> -->
                <hr>
            </form>
        </div>
        </div>
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
            integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
            integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
        </script>
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>
            function startCalc() {
                interval = setInterval("calc()", 1);
            }

            function calc() {
                let diskon1 = 0;
                if (diskon1 === 0 || diskon1 === null) {
                    bayar1 = document.autoSumForm.bayar.value;
                    total_pembelian1 = document.autoSumForm.total_pembelian.value;
                    diskon1 = document.autoSumForm.diskon.value;
                    document.autoSumForm.sisa_bayar.value = bayar1 - total_pembelian1;
                }
                if (diskon1 >= 1) {
                    bayar1 = document.autoSumForm.bayar.value;
                    total_pembelian1 = document.autoSumForm.total_pembelian.value;
                    diskon1 = document.autoSumForm.diskon.value;
                    document.autoSumForm.sisa_bayar.value = bayar1 - (diskon1 * total_pembelian1 / 100);
                }
            }
            $(document).ready(function() {
                $('#id_detail').change(function() {
                    var id = $(this).val();

                    $.ajax({
                        type: 'POST', //method
                        url: 'Total_Pembelian.php', //action
                        data: {
                            id: id

                        },
                        success: function(data) {
                            var isi = JSON.parse(data);
                            $('#total_pembelian').val(isi.total_pembayaran);
                        }
                    });
                });
            });
        </script>
    </body>

    </html>

    <?php
    require_once 'footer.php';
    ?>
