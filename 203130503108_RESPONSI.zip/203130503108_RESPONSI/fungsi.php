<?php
require('koneksi.php');
?>

<?php
//fungsi untuk mengambil data pada sintaks query mysql
function query($query)
{
    //memanggil variabel global conn
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

//fungsi untuk menambah data pada tabel merk
function tambah_merk($data)
{
    //memanggil variabel global conn
    global $conn;
    //mendeklariskan variabel untuk tambah data
    $id_merk = htmlspecialchars($data["id_merk"]);
    $nama_merk = htmlspecialchars($data["nama_merk"]);
    $model_sepatu = htmlspecialchars($data["model_sepatu"]);

    //query untuk menambah data
    $query = "CALL InsertData_merk ('$id_merk', '$nama_merk', '$model_sepatu')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

//fungsi untuk mengubah data pada tabel merk
function ubah_merk($data)
{
    //memanggil variabel global conn
    global $conn;
    //mendeklariskan variabel untuk ubah data
    $id_merk = $data["id_merk"];
    $nama_merk = htmlspecialchars($data["nama_merk"]);
    $model_sepatu = htmlspecialchars($data["model_sepatu"]);

    //query untuk mengubah / updata data
    $query = "CALL UpdateData_merk ('$id_merk', '$nama_merk', '$model_sepatu')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

//fungsi untuk menghapus data pada tabel merk
function hapus_merk($id)
{
    //memanggil variabel global conn
    global $conn;
    //query untuk menghapus data
    mysqli_query($conn, "CALL DelateData_merk ('$id')");
    return mysqli_affected_rows($conn);
}

//fungsi untuk menambah data pada tabel sepatu
function tambah_sepatu($data)
{
    //memanggil variabel global conn
    global $conn;
    //mendeklarasikan variabel untuk tambah data
    $id_sepatu =  htmlspecialchars($data["id_sepatu"]);
    $id_merk = htmlspecialchars($data["id_merk"]);
    $ukuran = htmlspecialchars($data["ukuran"]);
    $warna = htmlspecialchars($data["warna"]);
    $harga = htmlspecialchars($data["harga"]);
    $stok = htmlspecialchars($data["stok"]);

    //query untuk menambah data
    $query = "CALL InsertData_Sepatu ('$id_sepatu', '$id_merk', '$ukuran', '$warna', '$harga', '$stok')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

//fungsi untuk mengubah data pada tabel sepatu
function ubah_sepatu($data)
{
    //memanggil variabel global conn
    global $conn;
    //mendeklarasikan variabel untuk ubah data
    $id_sepatu =  $data["id_sepatu"];
    // $id_merk = $data["id_merk"];
    $ukuran = htmlspecialchars($data["ukuran"]);
    $warna = htmlspecialchars($data["warna"]);
    $harga = htmlspecialchars($data["harga"]);
    $stok = htmlspecialchars($data["stok"]);

    //query untuk mengubah / update data
    $query = "CALL UpdateData_Sepatu ('$id_sepatu', '$ukuran', '$warna', '$harga', '$stok')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

//fungsi untuk menghapus data pada tabel sepatu
function hapus_sepatu($id)
{
    //memanggil variabel global conn
    global $conn;
    //query untuk menghapus data
    mysqli_query($conn, "CALL DelateData_sepatu ('$id')");
    return mysqli_affected_rows($conn);
}

function tambah_detail($data)
{
    //memanggil variabel global conn
    global $conn;
    //mendeklarasikan variabel untuk tambah data
    $id_detail =  htmlspecialchars($data["id_detail"]);
    $id_sepatu = htmlspecialchars($data["id_sepatu"]);
    $jumlah_beli = htmlspecialchars($data["jumlah_beli"]);

    //query untuk menambah data
    $query = "CALL InsertData_detail ('$id_detail', '$id_sepatu', '$jumlah_beli')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function ubah_detail($data)
{
    //memanggil variabel global conn
    global $conn;
    //mendeklarasikan variabel untuk tambah data
    $id_detail =  htmlspecialchars($data["id_detail"]);
    // $id_sepatu = htmlspecialchars($data["id_sepatu"]);
    $jumlah_beli = htmlspecialchars($data["jumlah_beli"]);

    //query untuk menambah data
    $query = "CALL UpdateData_detail ('$id_detail','$jumlah_beli')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function hapus_detail($id)
{
    //memanggil variabel global conn
    global $conn;
    //query untuk menghapus data
    mysqli_query($conn, "CALL DelateData_detail ('$id')");
    return mysqli_affected_rows($conn);
}

function tambah_header($data)
{
    //memanggil variabel global conn
    global $conn;
    //mendeklarasikan variabel untuk tambah data
    $no_nota =  htmlspecialchars($data["no_nota"]);
    $tanggal = htmlspecialchars($data["tanggal"]);
    $id_detail = htmlspecialchars($data["id_detail"]);
    $total_pembelian = htmlspecialchars($data["total_pembelian"]);
    $bayar =  htmlspecialchars($data["bayar"]);
    $sisa_bayar = htmlspecialchars($data["sisa_bayar"]);
    //query untuk menambah data
    $query = "CALL InsertData_header ('$no_nota','$tanggal',' $id_detail', '$total_pembelian', '$bayar','$sisa_bayar')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function hapus_header($id)
{
    //memanggil variabel global conn
    global $conn;
    //query untuk menghapus data
    mysqli_query($conn, "CALL DelateData_header('$id')");
    return mysqli_affected_rows($conn);
}


function ubah_header($data)
{
    //memanggil variabel global conn
    global $conn;
    //mendeklarasikan variabel untuk tambah data
    $no_nota =  htmlspecialchars($data["no_nota"]);
    $tanggal = htmlspecialchars($data["tanggal"]);
    $total_pembelian = htmlspecialchars($data["total_pembelian"]);
    $bayar =  htmlspecialchars($data["bayar"]);
    $sisa_bayar = htmlspecialchars($data["sisa_bayar"]);
    //query untuk menambah data
    $query = "CALL UpdateData_header ('$no_nota','$tanggal', '$total_pembelian','$bayar','$sisa_bayar')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}
?>

