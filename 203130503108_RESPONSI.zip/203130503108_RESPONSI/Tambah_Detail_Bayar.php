<?php
//Memanggil fungsi agar dapat menjalankan program tertentu
require 'fungsi.php';

//Mengecek apakah data berhasil di tambah
if (isset($_POST["submit"])) {
    if (tambah_detail($_POST) > 0) {
        //Jika berhasil, maka akan muncul pesan ini
        echo "
        <script>
            alert('Data berhasil ditambahkan!');
            document.location.href = 'Detail_Bayar.php';
        </script>";
    } else {
        //Jika tidak berhasil, maka akan muncul pesan ini
        echo "
		<script>
			alert('Data gagal ditambahkan!');
			document.location.href = 'Detail_Bayar.php';
		</script>";
    }
}
?>

<?php
include("koneksi.php");
$data = mysqli_query($conn, "SELECT max((id_detail) + 1) as id_de FROM detail_bayar");
$row = mysqli_fetch_array($data);
?>

<?php
include("koneksi.php");
$data2 = mysqli_query($conn, "SELECT max(id_sepatu) as id_se FROM sepatu");
$row2 = mysqli_fetch_array($data2);
?>

<DOCTYPE html>
    <html>

    <head>
        <title>Tambah Data Sepatu</title>

        <!-- Membutuhkan meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    </head>

    <body>
        <!--Navbar pada bagian atas-->
        <nav class="navbar fix-top navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">Home</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <!--Bagian Menu Navbar-->
                        <a class="nav-link active" aria-current="page" href="Merk.php">Merk</a>
                        <a class="nav-link active" aria-current="page" href="Sepatu.php">Sepatu</a>
                        <a class="nav-link active" aria-current="page" href="Detail_Bayar.php">Detail Bayar</a>
                        <a class="nav-link active" aria-current="page" href="Header_Bayar.php">Header Bayar</a>
                    </div>
                </div>
            </div>
        </nav>

        <!--Menampilkan judul untuk web ini-->
        <div class="container">
        <br>
        <h1 class="display-4">Tambah Detail Bayar</h1>
        <hr>



        <!--Form untuk input data yang akan di tambah-->
        <form class="form-horizontal" method="POST" action="">

                    <!--Bagian untuk input Model Sepatu-->
                    <div class="mb-3 row">
                <label for="id_detail" class="col-sm-2 col-form-label">ID Detail</label>
                <div class="col-sm-10">
                    <input type="text" name="id_detail" class="form-control" id="id_detail"  value=" <?php echo $row['id_de']; ?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="id_sepatu" class="col-sm-2 col-form-label">ID Sepatu</label>
                <div class="col-sm-10">
                    <input type="text" name="id_sepatu" class="form-control" id="id_sepatu"  value=" <?php echo $row2['id_se']; ?>">
                </div>
            </div>
            <!--Bagian untuk input nama merk-->
            <div class="mb-3 row">
                <label for="jumlah_beli" class="col-sm-2 col-form-label">jumlah_beli</label>
                <div class="col-sm-10">
                    <input type="text" name="jumlah_beli" class="form-control" id="jumlah_beli" >
                </div>
            </div>


<hr>
            <button class="btn btn-success" type="submit" name="submit">Tambah Data</button>
            <a href="Merk.php" onclick=" return confirm ('Apakah anda ingin membatalkan data ini?');"><button
          type="button" class="btn btn-danger">
          <span><i class="fa fa-arrow-left white"></i> Batal</button></span></a>
            <!-- <i class="fa-solid fa-delete-left"></i> -->
            <hr>
        </form>
        
</div>

        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    </body>

    </html>